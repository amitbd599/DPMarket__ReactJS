
import ScrollToTop from "react-scroll-to-top";
export default function BootstrapInit() {

  return <>
    <ScrollToTop smooth color="#B94BF0" />
  </>;
}
